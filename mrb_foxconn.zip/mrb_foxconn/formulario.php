<!DOCTYPE html>
<html>
    <head>
    
    <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="Unknown" >
	  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
    <title>MRB_Foxconn_MRB</title>
    </head>
   <body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="notificacion.html">Foxconn</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Notificacion">
          <a class="nav-link" href="notificacion.html">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Notificacion</span>
          </a>
        </li>
    </div>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">My Dashboard</li>
      </ol>
      
      <div class="Notificacion"><center>
	<?php
	include 'con_bd.php';#requiere la base de datos para hacer la conexion a la misma
	$link = connection();
	#declaracion de variables
	#$ID=$_POST['id']; ya
	$PN=$_POST['pn'];//ya
	$SN=$_POST['sn'];//ya
	$QTY=$_POST['qty'];//ya
	$Origen=$_POST['origin'];//
	$Vendor=$_POST['vendor'];
	$Prioridad=$_POST['Prioridad'];
	$DM=$_POST['Descripcion_Material'];
	$MBD=$_POST['mbd'];
	$Dispos=$_POST['Disposittion'];
	$CF=$_POST['Code_Fail'];
	$DF=$_POST['desc_fail'];
	$Line=$_POST['Linea'];
	$sql= "INSERT INTO notificacion VALUES('','$PN','$SN','$DM','$CF','$DF','$Vendor','$Origen','$Prioridad','$MBD','$Dispos','$QTY','$Line')";
	$resultado =$link -> query($sql);
	if(!$resultado ) {
			echo '<script language="JavaScript">alert("No se pudo hacer el registro favor de llenar los campos correctamente");</script>';
			echo "<script>location.href='notificacion.html'</script>";
			mysqli_error();
		}else {
			echo '<script language="JavaScript">alert("Se Registro con exito");</script>';
		}
	#echo $sql;
	
	mysqli_close($link);
	?>
	</div>
	</body>
</html>


