<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="Unknown" >
  <title>MRB_Foxconn_Notificacion</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
<?php
function obtener_datos () {
	obtener_datos =  
$PN = ['pn'];
}
?>
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="#">Foxconn</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Notificacion">
          <a class="nav-link" href="notificacion.html">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Notificacion</span>
          </a>
        </li>
    </div>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid">
    <!desde aqui empieza el div de la etiqueta>
     <div class="container" id="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header">Notificacion</div><br/>
      <div class="card-body">
        <form action="formulario.php" method="POST">
         <div class="form-row">
			<div class="col-md-6">
          <label for="pn">P/N:</label><br>
           <input type="text" id="$txtpn" name="pn" required/><img src="barcode.php <?php text=$PN ?> &size=20&codetype=Code39&print=true" />
          </div><br>
          <div class="col-md-6">
          <label for="sn">S/N:</label><br>
            <input type="text" id="$txtsn" name="sn" required/><br/>
          </div>
          </div>
          <div class="form-row">
			<div class="col-md-6">
          <label for="qty">Cantidad</label><br>
				<input type="text" id="$txtqty" name="qty"required/><br/>
          </div>
          <div class="col-md-6">
          <label for="origin">Origen</label><br>
				<input type="text" id="$txtorigin" name="origin" required /><br/>
          </div>
          </div>
          <div class="form-row">
			<div class="col-md-6">
          <label for="Linea">Linea</label>
            <select id="Linea" name="Linea">
        <option value="selecciona una opcion" selected="selected"> selecciona una opcion</option>
		<option value="Butser" selected="selected">Butser</option>
		<option value="Camaro" selected="selected">Camaro</option>
		<option value="Cobra" selected="selected">Cobra</option>
		<option value="Controller Assy" selected="selected">Controller Assy</option>
		<option value="FA1" selected="selected">FA1</option>
		<option value="FA2" selected="selected">FA2</option>
		<option value="FA3" selected="selected">FA3</option>
		<option value="Warranty" selected="selected">Warranty</option>
		<option value="Onestor" selected="selected">Onestor</option>
		<option value="Talladega" selected="selected">Talladega</option>
		<option value="Titan" selected="selected">Titan</option>
		<option value="Warehouse" selected="selected">Warehouse</option>
        </select><br/>
          </div><br>
            <div class="form-row">
          <label for="Prioridad">Prioridad</label>
		<select id="Prioridad" name="Prioridad">
      <option value="" selected="selected"> selecciona una opcion</option>
		<option value="medio" selected="selected">medio</option>
		<option value="FA3" selected="selected">FA3</option>
		</select>
          </div>
          </div>
          <div class="form-row">
			<div class="col-md-6">
          <label for="vendor">Vendor</label><br>
          <input type="text" id="$txtvendor" name="vendor" required /><br/>
          </div></br>
          <div class="col-md-6">
          <label for="MBD">MBD</label><br>
            <input type="text" id="$txtmbd" name="mbd" required  /><br/>	
          </div>
          </div>
          <div class="form-row">
			<div class="col-md-6">
          <label for="Descripcion Material">Desc Mat</label>
            <select id="Descripcion_Material" name="Descripcion_Material">
        	<option value="" selected="selected">selecciona una opcion</option>
		<option value="bag" selected="selected">bag</option>
		<option value="baseplane asm" selected="selected">baseplane asm</option>
		<option value="baseplate" selected="selected">baseplate</option>
		<option value="battery" selected="selected">battery</option>
		<option value="bezel" selected="selected">bezel</option>
		<option value="blaking plate" selected="selected">blaking plate</option>
		<option value="braket" selected="selected">braket</option>
		<option value="cable" selected="selected">cable</option>
		<option value="capacitor" selected="selected">capacitor</option>
		<option value="carrier" selected="selected">carrier</option>
		<option value="cd" selected="selected">cd</option>
		<option value="chassis" selected="selected">chassis</option>
		<option value="controller" selected="selected">controller</option>
		<option value="cover" selected="selected">cover</option>
		<option value="CPU" selected="selected">CPU</option>
		<option value="disk drive" selected="selected">disk drive</option>
		<option value="document" selected="selected">document</option>
		<option value="dongle" selected="selected">dongle</option>
		<option value="fan" selected="selected">fan</option>
		<option value="fantray" selected="selected">fantray</option>
		<option value="fascia" selected="selected">fascia</option>
		<option value="foam" selected="selected">foam</option>
		<option value="heatsink" selected="selected">heatsink</option>
		<option value="label" selected="selected">label</option>
		<option value="latch" selected="selected">latch</option>
		<option value="memory dimm" selected="selected">memory dimm</option>
		<option value="midplane" selected="selected">midplane</option>
		<option value="module" selected="selected">module</option>
		<option value="motherboard" selected="selected">motherboard</option>
		<option value="ops panel" selected="selected">ops panel</option>
		<option value="packaging" selected="selected">packaging</option>
		<option value="pallet" selected="selected">pallet</option>
		<option value="panel rack" selected="selected">panel rack</option>
		<option value="pcba" selected="selected">pcba</option>
		<option value="power dist unit raritan" selected="selected">power dist unit raritan</option>
		<option value="power supply" selected="selected">power supply</option>
		<option value="psu" selected="selected">psu</option>
		<option value="rack" selected="selected">rack</option>
		<option value="rail kit" selected="selected">rail kit</option>
		<option value="screw" selected="selected">screw</option>
		<option value="server" selected="selected">server</option>
		<option value="sideplane" selected="selected">sideplane</option>
		<option value="switch" selected="selected">switch</option>
		<option value="tool screw" selected="selected">tool screw</option>
        </select>
          </div><br/>
			<div class="col-md-6">
          <label for="Disposittion">Disposittion</label>
            <select id="Linea" name="Disposittion">
        <option value="-1" selected="selected"> selecciona una opcion</option>
		<option value="FA2" selected="selected">FA2</option>
		<option value="Rework local" selected="selected">Rework local</option>
		<option value="Rework vendor" selected="selected">Rework vendor</option>
		<option value="RMAR" selected="selected">RMAR</option>
		<option value="Scrap" selected="selected">Scrap</option>
		<option value="OnHold" selected="selected">OnHold</option>
		</select>
          </div>
          </div><br>
          <div class="form-group">
          <label for="Codigo de falla">Codigo de falla</label><br>
            <input type="text" id="$txtCode_Fail" name="Code_Fail" required /><br/>
          </div>
          <div class="form-group">
          <label for="Descripcion de falla">Descripcion de falla</label><br>
            <textarea rows="4" cols="50"name="desc_fail"></textarea>
          </div>
          <script type="text/javascript">
			function imprSelec(container)
			{var ficha=document.getElementById(container);var ventimp=window.print(' ','popimpr');ventimp.document.write(ficha.innerHTML);ventimp.document.close();ventimp.print();ventimp.close();}
			</script> 
			<!a href="javascript:imprSelec('muestra')">Imprimir</a>
			<input type="button" value="Imprimir" onclick="javascript:imprSelec('container');function imprSelec(container)
{var ficha=document.getElementById(container);var ventimp=window.open(' ','popimpr');ventimp.document.write(ficha.innerHTML);ventimp.document.close();ventimp.print();ventimp.close();};" />
          <!input type="submit" name="Guardar" onclick='window.print();' value="Guardar" />  
        </form>
      </div>
    </div>
  </div>  
 <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © Ing_Alejandro_Alaniz 2017</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.html">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
    <script src="js/sb-admin-charts.min.js"></script>
  </div>
</body>

</html>
