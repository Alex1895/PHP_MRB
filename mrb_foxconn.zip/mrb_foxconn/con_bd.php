<?php
	function connection(){
	$link =mysqli_connect("localhost","root","","mrb") or die ('Error al Conectar con la base de datos');
	/*if($link){
		mysqli_select_db("mrb",$link); #or die('no se pudo seleccionar la base de datos' mysql_close());
	}*/
		return $link;
}
?>