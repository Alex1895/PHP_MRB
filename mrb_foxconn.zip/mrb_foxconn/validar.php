﻿<?php
	include 'con_bd.php';
	$link = connection();
	$user=$_POST['user'];
	$pass=$_POST['password'];
	$sql = "SELECT * FROM usuarios WHERE nombre='$user'";
	$resultado = $link->query($sql);
	if($f=mysqli_fetch_array($resultado)){
		if($pass==$f['pass']){ 
			header("Location: notificacion.html");
			

		}else{
			echo '<script>alert("CONTRASEÑA INCORRECTA")</script> ';
		
			echo "<script>location.href='ingresar.html'</script>";
		}
	}
	else{
		
		echo '<script>alert("ESTE USUARIO NO EXISTE, PORFAVOR CONTACTE CON EL ADMINISTRADOR DEL SITIO PARA ASIGNARLE UN USUARIO")</script> ';
		
		#echo "<script>location.href='registro.html'</script>";	
		

	}
	#if ($regis) { 
	#	header('Location: registro.html');
		
	#	}
?>